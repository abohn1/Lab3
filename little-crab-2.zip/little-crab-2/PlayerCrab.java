import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * This class defines a crab. Crabs live on the beach.
 * 
 * This crab is controlled by the player and won't move without keyboard input.
 */
public class PlayerCrab extends Actor
{
    /** 
     * Act - do whatever the crab wants to do. This method is called whenever
     *  the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        lookForWorm();
        
        /**
         * This part allows PlayerCrab to take input from the player
         */
        playerControls();
    }
    
    /**
     * Checks for worms, if the PlayerCrab finds a worm it will eat it. Otherwise it will do nothing.
     */
    public void lookForWorm()
    {
        if( isTouching(Worm.class) )
        {
            removeTouching(Worm.class);
            Greenfoot.playSound("slurp.wav");
        }
    }
    
    public void playerControls()
    {
        if (Greenfoot.isKeyDown("left") )
        {
            turn(-4);
        }
        if (Greenfoot.isKeyDown("right") )
        {
            turn(4);
        }
        if (Greenfoot.isKeyDown("up") )
        {
            move(4);
        }
        if (Greenfoot.isKeyDown("down") )
        {
            move(-4);
        }
    }
}
    
