import greenfoot.*;  // (Actor, World, Greenfoot, GreenfootImage)

public class CrabWorld extends World
{
    /**
     * Create the crab world (the beach). Our world has a size 
     * of 560x560 cells, where every cell is just 1 pixel.
     *EDIT: size was changed
     */
    public CrabWorld() 
    {
        super(900, 400, 1);
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        PlayerCrab playercrab = new PlayerCrab();
        addObject(playercrab,458,351);
        Worm worm = new Worm();
        addObject(worm,605,323);
        Worm worm2 = new Worm();
        addObject(worm2,501,279);
        Worm worm3 = new Worm();
        addObject(worm3,386,293);
        Worm worm4 = new Worm();
        addObject(worm4,327,364);
        Worm worm5 = new Worm();
        addObject(worm5,180,364);
        Worm worm6 = new Worm();
        addObject(worm6,305,235);
        Worm worm7 = new Worm();
        addObject(worm7,518,183);
        Worm worm8 = new Worm();
        addObject(worm8,680,248);
        Worm worm9 = new Worm();
        addObject(worm9,748,369);
        Worm worm10 = new Worm();
        addObject(worm10,872,355);
        Worm worm11 = new Worm();
        addObject(worm11,841,253);
        Worm worm12 = new Worm();
        addObject(worm12,661,132);
        Worm worm13 = new Worm();
        addObject(worm13,386,124);
        Worm worm14 = new Worm();
        addObject(worm14,190,264);
        Worm worm15 = new Worm();
        addObject(worm15,91,356);
        Worm worm16 = new Worm();
        addObject(worm16,103,251);
        Worm worm17 = new Worm();
        addObject(worm17,257,133);
        Worm worm18 = new Worm();
        addObject(worm18,538,52);
        Worm worm19 = new Worm();
        addObject(worm19,828,123);
        Worm worm20 = new Worm();
        addObject(worm20,700,51);
        Worm worm21 = new Worm();
        addObject(worm21,858,48);
        Worm worm22 = new Worm();
        addObject(worm22,326,54);
        Worm worm23 = new Worm();
        addObject(worm23,153,157);
        Worm worm24 = new Worm();
        addObject(worm24,44,167);
        Worm worm25 = new Worm();
        addObject(worm25,81,50);
        Worm worm26 = new Worm();
        addObject(worm26,231,67);
        Lobster lobster = new Lobster();
        addObject(lobster,752,127);
        Lobster lobster2 = new Lobster();
        addObject(lobster2,132,98);
    }
}
